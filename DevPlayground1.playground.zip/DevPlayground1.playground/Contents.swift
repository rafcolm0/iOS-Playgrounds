import UIKit

var str = "Hello, playground"

var counts:[String:Int] = [:];  //for keeping track of the code counts

func generateCode(code:String?) -> String{
    guard let code = code, code.count > 2 else {
        return "";
    }
    if let count = counts[code]{
        let newCount = count+1;
        counts[code] = newCount;
        return code.appending("-".appending(String(newCount)));
    } else {
        counts[code] = 1;
        return code.appending("-1");
    }
}

print(generateCode(code:"MIA"));
print(generateCode(code:"MIA"));
print(generateCode(code:"MIA"));
print(generateCode(code:"NYC"));
print(generateCode(code:"MIA"));
